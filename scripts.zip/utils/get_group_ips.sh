#!/bin/bash

for i in `cf ic group list -q`
do
	echo
	echo "Getting name and Loadbalancer IP address for container group with ID: ${i}"	
	echo
	INSPECT=`cf ic group inspect $i`	
	GROUP_NAME=`echo ${INSPECT} | jq -r .Name`	
	echo "Group name:       ${GROUP_NAME}"	

	#IMAGE=`cf ic group inspect $i | jq -r .ImageName`

	LOAD_BALANCER_IP=`echo ${INSPECT} | jq -r .Loadbalancer.private_ip_address`
	echo "Loadbalancer IP:  ${LOAD_BALANCER_IP}"
done
exit 0 
