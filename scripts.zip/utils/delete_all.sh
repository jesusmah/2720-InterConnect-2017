#!/bin/bash

echo "Removing container groups..."

for i in `cf ic group list -q`
do
	echo
	cf ic group rm ${i}
	if [ $? -ne 0 ]; then
		echo "[ERROR]: an problem has occurred when removing container group with ID: ${i} "
		exit 1
	fi
done

echo "Removing public routes..."

for i in `cf routes | grep mybluemix | awk '{print $2}'`
do

	echo
	echo "Removing public route: ${i}.mybluemix.net"
	cf delete-route -f mybluemix.net -n ${i}
	if [ $? -ne 0 ]; then
		echo "[ERROR]: an problem has occurred when removing public route: ${i}.mybluemix.net "
		exit 1
	fi
done

exit 0
