#!/bin/bash

for i in `docker ps -q`
do

	echo
	echo "Inspecting Docker container with ID: $i"
	echo
	CONTAINER_IMAGE=`docker inspect ${i} | jq -r '.[0].Config.Image'`
	echo "Container Image:        ${CONTAINER_IMAGE}"
	CONTAINER_IP=`docker inspect ${i} | jq -r '.[0].NetworkSettings.IPAddress'`
	echo "Container IP Address:   ${CONTAINER_IP}"
done
exit 0
