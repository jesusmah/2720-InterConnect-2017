#!/bin/bash

echo
echo "Going to kill each of the Java applications making up the IBM InterConnect 2017 menu:"
echo

for i in `ps -f | grep interconnect | grep java | awk '{print $2}'`
do 
	echo "Killing process number $i"
	kill -9 $i
	if [ $? -ne 0 ]; then
		echo "[ERROR]: An error occurred killing process number $i"
		exit 1
	fi
	echo "Done"
	echo
done

echo "[OK]: All Java applications killed"
echo
exit 0
